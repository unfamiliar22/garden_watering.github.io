# Умный полив сада 🌱💧

Веб-приложение на Django для управления автоматической системой полива растений на дачном участке.

## Возможности

- 🔐 **Регистрация и авторизация пользователей**
- 🌿 **Управление зонами полива** — создавайте неограниченное количество зон
- 📅 **Расписание полива** — настраивайте автоматический полив по дням недели
- 🎮 **Ручной запуск полива** — мгновенный полив в один клик
- 📊 **История и статистика** — отслеживайте расход воды и историю поливов
- 📡 **API для интеграции** — подключайте датчики и контроллеры
- 📱 **Адаптивный дизайн** — работает на компьютерах, планшетах и смартфонах

## Технологии

- **Backend**: Django 5.0
- **Database**: SQLite (встроенная)
- **Frontend**: Bootstrap 5, Bootstrap Icons
- **CSS**: Кастомные стили
- **JavaScript**: Vanilla JS с Fetch API

## Установка и запуск

### 1. Клонирование репозитория

```bash
cd garden_watering
```

### 2. Создание виртуального окружения

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Установка зависимостей

```bash
pip install -r requirements.txt
```

### 4. Применение миграций

```bash
python manage.py migrate
```

### 5. Создание суперпользователя (опционально)

```bash
python manage.py createsuperuser
```

### 6. Запуск сервера

```bash
python manage.py runserver
```

Откройте браузер и перейдите по адресу: **http://127.0.0.1:8000/**

## Структура проекта

```
garden_watering/
├── garden_watering/          # Настройки проекта Django
│   ├── __init__.py
│   ├── settings.py           # Конфигурация
│   ├── urls.py               # URL-маршруты проекта
│   ├── wsgi.py
│   └── asgi.py
├── main/                      # Основное приложение
│   ├── __init__.py
│   ├── admin.py              # Админ-панель
│   ├── models.py             # Модели данных
│   ├── views.py              # Представления
│   ├── forms.py              # Формы
│   ├── urls.py               # URL-маршруты приложения
│   └── migrations/           # Миграции базы данных
├── templates/                 # HTML-шаблоны
│   ├── base.html             # Базовый шаблон
│   └── main/                 # Шаблоны приложения
│       ├── home.html
│       ├── register.html
│       ├── login.html
│       ├── profile.html
│       ├── dashboard.html
│       ├── zone_form.html
│       ├── schedule_form.html
│       ├── start_watering.html
│       └── watering_history.html
├── static/                    # Статические файлы
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── manage.py                  # Управление проектом
├── requirements.txt           # Зависимости
└── README.md                  # Документация
```

## Модели данных

### UserProfile
Расширенный профиль пользователя с телефоном и адресом.

### GardenZone
Зона полива с настройками:
- Название и описание
- Тип растений
- Площадь
- Длительность и частота полива

### WateringSchedule
Расписание полива:
- Время
- Дни недели
- Статус (активно/неактивно)

### WateringLog
История поливов:
- Дата и время
- Длительность
- Расход воды
- Тип (ручной/автоматический)

### SensorReading
Показания датчиков:
- Влажность почвы
- Температура
- Влажность воздуха

### SystemStatus
Статус системы полива:
- Онлайн/офлайн
- Давление воды
- Общий расход воды

## API Endpoints

| Endpoint | Метод | Описание |
|----------|-------|----------|
| `/api/zone/<id>/status/` | GET | Получить статус зоны |
| `/api/schedule/<id>/toggle/` | POST | Включить/выключить расписание |

## Интеграция с оборудованием

Для подключения реальных датчиков и контроллеров используйте API:

```python
import requests

# Отправка показаний датчика
requests.post('http://your-server/api/sensor-data/', json={
    'zone_id': 1,
    'soil_moisture': 65,
    'temperature': 24.5,
    'humidity': 70
})

# Получение команд на полив
response = requests.get('http://your-server/api/zone/1/status/')
status = response.json()
```

## Админ-панель

Доступна по адресу: **http://127.0.0.1:8000/admin/**

В админ-панели можно управлять:
- Пользователями и профилями
- Зонами полива
- Расписаниями
- Историей поливов
- Показаниями датчиков

## Разработка

### Добавление новой миграции

```bash
python manage.py makemigrations
python manage.py migrate
```

### Сбор статических файлов (для production)

```bash
python manage.py collectstatic
```

### Запуск тестов

```bash
python manage.py test
```

## Безопасность

- CSRF-защита форм
- Хеширование паролей
- Защита от SQL-инъекций
- XSS-защита
- Авторизация доступа к данным

## Лицензия

MIT License

## Контакты

Email: support@gardenwatering.ru
